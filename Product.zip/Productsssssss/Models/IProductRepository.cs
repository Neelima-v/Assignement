﻿using System.Collections.Generic;

namespace Productsssssss.Models
{
    public interface IProductRepository
    {
        IEnumerable<Products> GetAllProducts();
        Products GetProductById(int id);
        void AddProduct(Products pdt);
        void EditProduct(Products pdt);
        void DeleteProductById(int id);
    }
}
