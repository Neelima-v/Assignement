﻿namespace Productsssssss.Models
{
    public class Products
    {
        internal readonly int productId;

        public int ProductId { get; set; }
        public string Name { get; set; }

    }
}
