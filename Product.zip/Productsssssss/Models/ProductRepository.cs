﻿using System.Collections.Generic;
using System.Linq;

namespace Productsssssss.Models
{
    public class ProductRepository:IProductRepository
    {
        static List<Products> Products;
        static ProductRepository()
        {
            Products = new List<Products>()
            {
               new Products{ProductId=1,Name="DairlyMilk"},
               new Products{ProductId=2,Name="Kitkat"},
               new Products{ProductId=3,Name="5-Star"},
               new Products{ProductId=4,Name="Snickers"},
            };

        }
        public IEnumerable<Products> GetAllProducts()
        {
            return Products;
        }



        public Products GetProductById(int id)
        {
            Products product = Products.Where(s => s.productId == id).FirstOrDefault();
            return product;

        }
        public void AddProduct(Products pdt)
        {
            Products.Add(pdt);
        }
       
        public void EditProduct(Products pdt)
        {
            Products update = Products.Where(s => s.productId == pdt.productId).FirstOrDefault();
            if (update != null)
            {

                update.Name = pdt.Name;

            }
        }
        public void DeleteProductById(int id)
        {
            Products product = Products.Where(s => s.productId == id).FirstOrDefault();

            Products.Remove(product);
        }

       
    }
}
   