﻿using Microsoft.AspNetCore.Mvc;
using Productsssssss.Models;

namespace Productsssssss.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository repository = null;
        public ProductController(IProductRepository repo)
        {
            repository = repo;
        }
        public IActionResult Index()
        {
            return View(repository.GetAllProducts());
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Products pdt)
        {
            repository.AddProduct(pdt);

            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            return View(repository.GetProductById(id));
        }
        [HttpPost]
        public IActionResult Edit(Products pdt)
        {
            repository.EditProduct(pdt);

            return RedirectToAction("Index");
        }
        public IActionResult Details(int id)
        {
            return View(repository.GetProductById(id));
        }
        public IActionResult Delete(int id)
        {
            repository.DeleteProductById(id);
            return RedirectToAction("Index");
        }
    }
}
