﻿using System.Collections.Generic;

namespace DEmoMVC.Models
{
    public interface IStudentRepository
    {
        IEnumerable<Student> GetAllStudents();
        Student GetStudentById(int id);
        void AddStudent(Student std);
        void EditStudent(Student std);
        Student GetStudent(int id);
        void DeleteStudentById(int id);
    }
}
