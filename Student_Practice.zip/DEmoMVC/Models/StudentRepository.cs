﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Cache;

namespace DEmoMVC.Models
{
    public class StudentRepository:IStudentRepository
    {
        static List<Student> Students;
        static StudentRepository()
        {
            Students = new List<Student>()
            {
                new Student{studentId=1,name="Neelima",age=21,gender="Female"},
                new Student{studentId=2,name="Usha",age=20,gender="Female"},
                new Student{studentId=3,name="Bhav",age=22,gender="Male"},
                new Student{studentId=4,name="Jessi",age=21,gender="Male"}
            };

        }
        public IEnumerable<Student> GetAllStudents()
        {
            return Students;
        }



        public Student GetStudentsById(int id)
        {
            Student student = Students.Where(s => s.studentId == id).FirstOrDefault();
            return student;

        }
        public void AddStudent(Student std)
        {
            Students.Add(std);
        }
        public Student GetStudent(int id)
        {
            Student stdudent = Students.Where(s => s.studentId == id).FirstOrDefault();

            return stdudent;
        }
        public void EditStudent(Student std)
        {
            Student update = Students.Where(s => s.studentId == std.studentId).FirstOrDefault();
            if (update != null)
            {

                update.name = std.name;
                update.gender = std.gender;
                
            }
        }
        public void DeleteStudentById(int id)
        {
            Student student = Students.Where(s => s.studentId == id).FirstOrDefault();

            Students.Remove(student);
        }

        public Student GetStudentById(int id)
        {
            throw new System.NotImplementedException();
        }
    }
}
