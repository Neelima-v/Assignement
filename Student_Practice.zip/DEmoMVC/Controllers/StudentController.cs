﻿using DEmoMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System;

namespace DEmoMVC.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentRepository repository = null;
        public StudentController(IStudentRepository repo)
        {
            repository = repo;
        }
        public IActionResult Index()
        {
            return View(repository.GetAllStudents());
        }
        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]

        public IActionResult Create(Student std)
        {
            repository.AddStudent(std);

            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            return View(repository.GetStudent(id));
        }
        public IActionResult Edit(Student std)
        {
            repository.EditStudent(std);

            return RedirectToAction("Index");
        }
        public IActionResult Details(int id)
        {
            return View(repository.GetStudent(id));
        }
        public IActionResult Delete(int id)
        {
            repository.DeleteStudentById(id);
            return RedirectToAction("Index");
        }
    }
}
